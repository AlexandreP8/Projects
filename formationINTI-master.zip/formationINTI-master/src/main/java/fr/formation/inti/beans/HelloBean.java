package fr.formation.inti.beans;

public class HelloBean {

	
	
	public HelloBean() {
		System.out.println("Création du HelloBean...");
	}
	public void hello() {
		System.out.println("Bonjour !");
	}
}
